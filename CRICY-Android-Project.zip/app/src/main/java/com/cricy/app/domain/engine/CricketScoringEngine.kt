package com.cricy.app.domain.engine

import com.cricy.app.data.local.entity.DeliveryEntity
import com.cricy.app.data.local.entity.MatchEntity
import com.cricy.app.data.local.entity.PlayerEntity
import com.cricy.app.data.local.entity.TeamEntity
import com.cricy.app.domain.model.BatterMatchStats
import com.cricy.app.domain.model.BowlerMatchStats
import com.cricy.app.domain.model.DeliveryChip
import com.cricy.app.domain.model.ExtraType
import com.cricy.app.domain.model.ExtrasBreakdown
import com.cricy.app.domain.model.FallOfWicket
import com.cricy.app.domain.model.InningsScoreboard
import com.cricy.app.domain.model.MatchLiveState
import com.cricy.app.domain.model.PartnershipStats
import com.cricy.app.domain.model.WicketType

/**
 * Pure, deterministic cricket rules engine.
 * Computes full live scoreboard state, strike rotation, overs, target/RRR,
 * partnerships, fall of wickets, and match results from ordered ball-by-ball deliveries.
 */
object CricketScoringEngine {

    fun parseIdList(csv: String): List<Long> =
        csv.split(",").mapNotNull { it.trim().toLongOrNull() }

    fun buildLiveState(
        match: MatchEntity,
        deliveries: List<DeliveryEntity>,
        teamA: TeamEntity,
        teamB: TeamEntity,
        allPlayers: List<PlayerEntity>
    ): MatchLiveState {
        val playerMap = allPlayers.associateBy { it.id }
        val teamASquadIds = parseIdList(match.teamASquadIdsCsv)
        val teamBSquadIds = parseIdList(match.teamBSquadIdsCsv)

        val teamASquad = if (teamASquadIds.isNotEmpty()) {
            teamASquadIds.mapNotNull { playerMap[it] }
        } else {
            allPlayers.filter { it.teamId == teamA.id }
        }
        val teamBSquad = if (teamBSquadIds.isNotEmpty()) {
            teamBSquadIds.mapNotNull { playerMap[it] }
        } else {
            allPlayers.filter { it.teamId == teamB.id }
        }

        val firstBattingTeam = if (match.battingFirstTeamId == teamA.id) teamA else teamB
        val firstBowlingTeam = if (firstBattingTeam.id == teamA.id) teamB else teamA
        val firstBattingSquad = if (firstBattingTeam.id == teamA.id) teamASquad else teamBSquad
        val firstBowlingSquad = if (firstBowlingTeam.id == teamA.id) teamASquad else teamBSquad

        val innings1Deliveries = deliveries.filter { it.inningsNumber == 1 }.sortedBy { it.sequenceNumber }
        val innings2Deliveries = deliveries.filter { it.inningsNumber == 2 }.sortedBy { it.sequenceNumber }

        val innings1 = computeInningsScoreboard(
            inningsNumber = 1,
            battingTeam = firstBattingTeam,
            bowlingTeam = firstBowlingTeam,
            battingSquad = firstBattingSquad,
            bowlingSquad = firstBowlingSquad,
            deliveries = innings1Deliveries,
            oversLimit = match.oversLimit,
            initialStrikerId = match.innings1StrikerId,
            initialNonStrikerId = match.innings1NonStrikerId,
            initialBowlerId = match.innings1BowlerId,
            overrideStrikerId = if (match.currentInnings == 1) match.activeStrikerId else null,
            overrideNonStrikerId = if (match.currentInnings == 1) match.activeNonStrikerId else null,
            overrideBowlerId = if (match.currentInnings == 1) match.activeBowlerId else null,
            targetRuns = null,
            forceCompleted = match.currentInnings == 2 || match.status == "INNINGS_BREAK" || match.status == "COMPLETED"
        )

        val target = innings1.totalRuns + 1
        val showInnings2 = match.currentInnings == 2 || innings2Deliveries.isNotEmpty()
        val innings2 = if (showInnings2) {
            computeInningsScoreboard(
                inningsNumber = 2,
                battingTeam = firstBowlingTeam,
                bowlingTeam = firstBattingTeam,
                battingSquad = firstBowlingSquad,
                bowlingSquad = firstBattingSquad,
                deliveries = innings2Deliveries,
                oversLimit = match.oversLimit,
                initialStrikerId = match.innings2StrikerId,
                initialNonStrikerId = match.innings2NonStrikerId,
                initialBowlerId = match.innings2BowlerId,
                overrideStrikerId = if (match.currentInnings == 2) match.activeStrikerId else null,
                overrideNonStrikerId = if (match.currentInnings == 2) match.activeNonStrikerId else null,
                overrideBowlerId = if (match.currentInnings == 2) match.activeBowlerId else null,
                targetRuns = target,
                forceCompleted = match.status == "COMPLETED"
            )
        } else {
            null
        }

        val activeInnings = if (match.currentInnings == 2 && innings2 != null) innings2 else innings1
        val activeBattingSquad = if (activeInnings.battingTeam.id == teamA.id) teamASquad else teamBSquad
        val activeBowlingSquad = if (activeInnings.bowlingTeam.id == teamA.id) teamASquad else teamBSquad

        val dismissedIds = activeInnings.batters.filter { it.isOut }.map { it.player.id }.toSet()
        val onCreaseIds = setOfNotNull(activeInnings.strikerId, activeInnings.nonStrikerId)
        val availableNextBatters = activeBattingSquad.filter { it.id !in dismissedIds && it.id !in onCreaseIds }

        val availableNextBowlers = activeBowlingSquad.filter {
            it.id != activeInnings.lastCompletedOverBowlerId || activeBowlingSquad.size <= 1
        }

        val needsSecondInningsOpeners =
            match.currentInnings == 1 && innings1.isCompleted && match.status != "COMPLETED"

        val isMatchCompleted = (innings2?.isCompleted == true) || match.status == "COMPLETED"

        val resultSummary = when {
            innings2 != null && isMatchCompleted -> computeMatchResult(
                innings1 = innings1,
                innings2 = innings2
            )
            match.resultSummary.isNotBlank() -> match.resultSummary
            else -> ""
        }

        val needsNextBatter = !activeInnings.isCompleted &&
            !needsSecondInningsOpeners &&
            !isMatchCompleted &&
            (activeInnings.strikerId == null || activeInnings.nonStrikerId == null) &&
            availableNextBatters.isNotEmpty()

        val needsNextBowler = !activeInnings.isCompleted &&
            !needsSecondInningsOpeners &&
            !isMatchCompleted &&
            activeInnings.currentBowlerId == null &&
            availableNextBowlers.isNotEmpty()

        return MatchLiveState(
            match = match,
            teamA = teamA,
            teamB = teamB,
            teamASquad = teamASquad,
            teamBSquad = teamBSquad,
            innings1 = innings1,
            innings2 = innings2,
            activeInnings = activeInnings,
            striker = activeInnings.strikerId?.let { playerMap[it] },
            nonStriker = activeInnings.nonStrikerId?.let { playerMap[it] },
            currentBowler = activeInnings.currentBowlerId?.let { playerMap[it] },
            availableNextBatters = availableNextBatters,
            availableNextBowlers = availableNextBowlers,
            needsNextBatter = needsNextBatter,
            needsNextBowler = needsNextBowler,
            needsSecondInningsOpeners = needsSecondInningsOpeners,
            isMatchCompleted = isMatchCompleted,
            resultSummary = resultSummary,
            canUndo = deliveries.isNotEmpty()
        )
    }

    fun computeInningsScoreboard(
        inningsNumber: Int,
        battingTeam: TeamEntity,
        bowlingTeam: TeamEntity,
        battingSquad: List<PlayerEntity>,
        bowlingSquad: List<PlayerEntity>,
        deliveries: List<DeliveryEntity>,
        oversLimit: Int,
        initialStrikerId: Long?,
        initialNonStrikerId: Long?,
        initialBowlerId: Long?,
        overrideStrikerId: Long?,
        overrideNonStrikerId: Long?,
        overrideBowlerId: Long?,
        targetRuns: Int?,
        forceCompleted: Boolean = false
    ): InningsScoreboard {
        val allPlayersMap = (battingSquad + bowlingSquad).associateBy { it.id }
        val maxWickets = (battingSquad.size - 1).coerceIn(1, 10)
        val totalAllowedBalls = oversLimit * 6

        var totalRuns = 0
        var wickets = 0
        var legalBalls = 0
        var wides = 0
        var noBalls = 0
        var byes = 0
        var legByes = 0

        val batterOrder = mutableListOf<Long>()
        val batterRuns = mutableMapOf<Long, Int>()
        val batterBalls = mutableMapOf<Long, Int>()
        val batterFours = mutableMapOf<Long, Int>()
        val batterSixes = mutableMapOf<Long, Int>()
        val batterOut = mutableMapOf<Long, Boolean>()
        val batterDismissal = mutableMapOf<Long, String>()

        val bowlerOrder = mutableListOf<Long>()
        val bowlerBalls = mutableMapOf<Long, Int>()
        val bowlerRuns = mutableMapOf<Long, Int>()
        val bowlerWickets = mutableMapOf<Long, Int>()
        val bowlerWides = mutableMapOf<Long, Int>()
        val bowlerNoBalls = mutableMapOf<Long, Int>()
        val bowlerMaidens = mutableMapOf<Long, Int>()

        // Track runs conceded by bowler per over to calculate maidens accurately
        val overBowlerRuns = mutableMapOf<Int, Int>()
        val overBowlerLegalBalls = mutableMapOf<Int, Int>()
        val overBowlerId = mutableMapOf<Int, Long>()

        val fallOfWickets = mutableListOf<FallOfWicket>()
        val partnerships = mutableListOf<PartnershipStats>()

        var derivedStrikerId: Long? = initialStrikerId
        var derivedNonStrikerId: Long? = initialNonStrikerId
        var derivedBowlerId: Long? = initialBowlerId
        var lastCompletedOverBowlerId: Long? = null

        fun ensureBatter(playerId: Long?) {
            if (playerId != null && playerId !in batterOrder && allPlayersMap.containsKey(playerId)) {
                batterOrder.add(playerId)
            }
        }

        fun ensureBowler(playerId: Long?) {
            if (playerId != null && playerId !in bowlerOrder && allPlayersMap.containsKey(playerId)) {
                bowlerOrder.add(playerId)
            }
        }

        ensureBatter(initialStrikerId)
        ensureBatter(initialNonStrikerId)
        ensureBowler(initialBowlerId)

        var currentPartnershipRuns = 0
        var currentPartnershipBalls = 0
        var partnershipPair: Pair<Long, Long>? = if (initialStrikerId != null && initialNonStrikerId != null) {
            initialStrikerId to initialNonStrikerId
        } else null

        for (d in deliveries) {
            ensureBatter(d.strikerId)
            ensureBatter(d.nonStrikerId)
            ensureBowler(d.bowlerId)

            if (partnershipPair == null) {
                partnershipPair = d.strikerId to d.nonStrikerId
            }

            derivedStrikerId = d.strikerId
            derivedNonStrikerId = d.nonStrikerId
            derivedBowlerId = d.bowlerId

            val extraType = ExtraType.fromString(d.extraType)
            val wicketType = WicketType.fromString(d.wicketType)

            val deliveryTotalRuns = d.runsOffBat + d.extraRuns
            totalRuns += deliveryTotalRuns
            currentPartnershipRuns += deliveryTotalRuns

            when (extraType) {
                ExtraType.WIDE -> wides += d.extraRuns
                ExtraType.NO_BALL -> noBalls += d.extraRuns
                ExtraType.BYE -> byes += d.extraRuns
                ExtraType.LEG_BYE -> legByes += d.extraRuns
                ExtraType.NONE -> {}
            }

            // Batter stats
            if (extraType != ExtraType.WIDE) {
                batterBalls[d.strikerId] = (batterBalls[d.strikerId] ?: 0) + 1
                currentPartnershipBalls += 1
            }
            if (d.runsOffBat > 0) {
                batterRuns[d.strikerId] = (batterRuns[d.strikerId] ?: 0) + d.runsOffBat
                if (d.runsOffBat == 4) batterFours[d.strikerId] = (batterFours[d.strikerId] ?: 0) + 1
                if (d.runsOffBat == 6) batterSixes[d.strikerId] = (batterSixes[d.strikerId] ?: 0) + 1
            }

            // Bowler stats (Byes & Leg Byes are NOT charged to bowler)
            val bowlerChargedRuns = d.runsOffBat +
                if (extraType == ExtraType.WIDE || extraType == ExtraType.NO_BALL) d.extraRuns else 0
            bowlerRuns[d.bowlerId] = (bowlerRuns[d.bowlerId] ?: 0) + bowlerChargedRuns
            if (extraType == ExtraType.WIDE) bowlerWides[d.bowlerId] = (bowlerWides[d.bowlerId] ?: 0) + d.extraRuns
            if (extraType == ExtraType.NO_BALL) bowlerNoBalls[d.bowlerId] = (bowlerNoBalls[d.bowlerId] ?: 0) + 1

            overBowlerId[d.overNumber] = d.bowlerId
            overBowlerRuns[d.overNumber] = (overBowlerRuns[d.overNumber] ?: 0) + bowlerChargedRuns

            if (d.countsAsLegalBall) {
                legalBalls += 1
                bowlerBalls[d.bowlerId] = (bowlerBalls[d.bowlerId] ?: 0) + 1
                overBowlerLegalBalls[d.overNumber] = (overBowlerLegalBalls[d.overNumber] ?: 0) + 1
            }

            // Strike rotation from runs completed on this ball
            val runsRunningBetweenWickets = when (extraType) {
                ExtraType.NONE -> d.runsOffBat
                ExtraType.WIDE -> (d.extraRuns - 1).coerceAtLeast(0)
                ExtraType.NO_BALL -> d.runsOffBat + (d.extraRuns - 1).coerceAtLeast(0)
                ExtraType.BYE, ExtraType.LEG_BYE -> d.extraRuns
            }
            if (runsRunningBetweenWickets % 2 == 1) {
                val temp = derivedStrikerId
                derivedStrikerId = derivedNonStrikerId
                derivedNonStrikerId = temp
            }

            // Wicket handling
            if (d.isWicket) {
                wickets += 1
                val dismissedId = d.dismissedPlayerId ?: d.strikerId
                batterOut[dismissedId] = true
                val bowlerName = allPlayersMap[d.bowlerId]?.name ?: "Bowler"
                val fielderName = d.fielderId?.let { allPlayersMap[it]?.name }
                val dismissalText = formatDismissal(wicketType, bowlerName, fielderName)
                batterDismissal[dismissedId] = dismissalText

                if (wicketType.creditsBowler) {
                    bowlerWickets[d.bowlerId] = (bowlerWickets[d.bowlerId] ?: 0) + 1
                }

                val dismissedName = allPlayersMap[dismissedId]?.name ?: "Batter"
                fallOfWickets.add(
                    FallOfWicket(
                        wicketNumber = wickets,
                        scoreAtFall = totalRuns,
                        overAtFall = "${legalBalls / 6}.${legalBalls % 6}",
                        batterName = dismissedName,
                        dismissalText = dismissalText
                    )
                )

                val pOneName = partnershipPair?.first?.let { allPlayersMap[it]?.name } ?: "Batter 1"
                val pTwoName = partnershipPair?.second?.let { allPlayersMap[it]?.name } ?: "Batter 2"
                partnerships.add(
                    PartnershipStats(
                        batterOneName = pOneName,
                        batterTwoName = pTwoName,
                        runs = currentPartnershipRuns,
                        balls = currentPartnershipBalls,
                        isActive = false
                    )
                )
                currentPartnershipRuns = 0
                currentPartnershipBalls = 0
                partnershipPair = null

                if (dismissedId == derivedStrikerId) {
                    derivedStrikerId = null
                } else if (dismissedId == derivedNonStrikerId) {
                    derivedNonStrikerId = null
                }
            }

            // Over completion (every 6th legal ball)
            if (d.countsAsLegalBall && legalBalls % 6 == 0) {
                val temp = derivedStrikerId
                derivedStrikerId = derivedNonStrikerId
                derivedNonStrikerId = temp
                lastCompletedOverBowlerId = d.bowlerId
                derivedBowlerId = null

                // Maiden over check
                if ((overBowlerLegalBalls[d.overNumber] ?: 0) == 6 && (overBowlerRuns[d.overNumber] ?: 0) == 0) {
                    bowlerMaidens[d.bowlerId] = (bowlerMaidens[d.bowlerId] ?: 0) + 1
                }
            }
        }

        // Apply active override selections (when user picks next batter / next bowler / swaps strike)
        val finalStrikerId = overrideStrikerId ?: derivedStrikerId
        val finalNonStrikerId = overrideNonStrikerId ?: derivedNonStrikerId
        val finalBowlerId = overrideBowlerId ?: derivedBowlerId

        ensureBatter(finalStrikerId)
        ensureBatter(finalNonStrikerId)
        ensureBowler(finalBowlerId)

        if (currentPartnershipRuns > 0 || currentPartnershipBalls > 0 || (finalStrikerId != null && finalNonStrikerId != null)) {
            val p1 = finalStrikerId ?: partnershipPair?.first
            val p2 = finalNonStrikerId ?: partnershipPair?.second
            if (p1 != null && p2 != null) {
                partnerships.add(
                    PartnershipStats(
                        batterOneName = allPlayersMap[p1]?.name ?: "Batter 1",
                        batterTwoName = allPlayersMap[p2]?.name ?: "Batter 2",
                        runs = currentPartnershipRuns,
                        balls = currentPartnershipBalls,
                        isActive = true
                    )
                )
            }
        }

        val currentOverIdx = legalBalls / 6
        val activeOverDeliveries = if (legalBalls > 0 && legalBalls % 6 == 0 && derivedBowlerId == null && finalBowlerId == null) {
            // Over just finished and next bowler hasn't been picked yet -> still show the completed over chips
            deliveries.filter { it.overNumber == currentOverIdx - 1 }
        } else {
            deliveries.filter { it.overNumber == currentOverIdx }
        }

        val currentOverChips = activeOverDeliveries.map { d ->
            val extra = ExtraType.fromString(d.extraType)
            val label = when {
                d.isWicket && d.runsOffBat > 0 -> "W+${d.runsOffBat}"
                d.isWicket -> "W"
                extra == ExtraType.WIDE -> if (d.extraRuns > 1) "Wd+${d.extraRuns - 1}" else "Wd"
                extra == ExtraType.NO_BALL -> if (d.runsOffBat > 0) "NB+${d.runsOffBat}" else "NB"
                extra == ExtraType.BYE -> "${d.extraRuns}B"
                extra == ExtraType.LEG_BYE -> "${d.extraRuns}LB"
                d.runsOffBat == 0 -> "•"
                else -> d.runsOffBat.toString()
            }
            DeliveryChip(
                id = d.id,
                label = label,
                isBoundaryFour = d.runsOffBat == 4,
                isBoundarySix = d.runsOffBat == 6,
                isWicket = d.isWicket,
                isExtra = extra != ExtraType.NONE
            )
        }

        val battersList = batterOrder.mapNotNull { pid ->
            val p = allPlayersMap[pid] ?: return@mapNotNull null
            val isOut = batterOut[pid] == true
            BatterMatchStats(
                player = p,
                runs = batterRuns[pid] ?: 0,
                balls = batterBalls[pid] ?: 0,
                fours = batterFours[pid] ?: 0,
                sixes = batterSixes[pid] ?: 0,
                isOut = isOut,
                dismissalText = if (isOut) batterDismissal[pid] ?: "out" else "not out",
                isOnStrike = pid == finalStrikerId
            )
        }

        val bowlersList = bowlerOrder.mapNotNull { pid ->
            val p = allPlayersMap[pid] ?: return@mapNotNull null
            BowlerMatchStats(
                player = p,
                legalBalls = bowlerBalls[pid] ?: 0,
                maidens = bowlerMaidens[pid] ?: 0,
                runsConceded = bowlerRuns[pid] ?: 0,
                wickets = bowlerWickets[pid] ?: 0,
                wides = bowlerWides[pid] ?: 0,
                noBalls = bowlerNoBalls[pid] ?: 0
            )
        }

        val remainingBalls = (totalAllowedBalls - legalBalls).coerceAtLeast(0)
        val requiredRuns = targetRuns?.let { (it - totalRuns).coerceAtLeast(0) }
        val crr = if (legalBalls == 0) 0.0 else (totalRuns * 6.0) / legalBalls
        val rrr = if (requiredRuns != null && remainingBalls > 0) {
            (requiredRuns * 6.0) / remainingBalls
        } else if (requiredRuns != null && requiredRuns > 0) {
            requiredRuns.toDouble()
        } else {
            null
        }

        val targetReached = targetRuns != null && totalRuns >= targetRuns
        val allOut = wickets >= maxWickets
        val oversFinished = legalBalls >= totalAllowedBalls
        val isCompleted = forceCompleted || targetReached || allOut || oversFinished

        return InningsScoreboard(
            inningsNumber = inningsNumber,
            battingTeam = battingTeam,
            bowlingTeam = bowlingTeam,
            totalRuns = totalRuns,
            wickets = wickets,
            legalBalls = legalBalls,
            oversLimit = oversLimit,
            maxWickets = maxWickets,
            extras = ExtrasBreakdown(wides = wides, noBalls = noBalls, byes = byes, legByes = legByes),
            currentRunRate = crr,
            targetRuns = targetRuns,
            requiredRuns = requiredRuns,
            remainingBalls = remainingBalls,
            requiredRunRate = rrr,
            batters = battersList,
            bowlers = bowlersList,
            partnerships = partnerships,
            fallOfWickets = fallOfWickets,
            currentOverChips = currentOverChips,
            strikerId = finalStrikerId,
            nonStrikerId = finalNonStrikerId,
            currentBowlerId = finalBowlerId,
            lastCompletedOverBowlerId = lastCompletedOverBowlerId,
            isCompleted = isCompleted
        )
    }

    fun computeMatchResult(
        innings1: InningsScoreboard,
        innings2: InningsScoreboard
    ): String {
        val target = innings1.totalRuns + 1
        return when {
            innings2.totalRuns >= target -> {
                val wicketsRemaining = (innings2.maxWickets - innings2.wickets).coerceAtLeast(1)
                val unit = if (wicketsRemaining == 1) "wicket" else "wickets"
                "${innings2.battingTeam.name} won by $wicketsRemaining $unit"
            }
            innings2.totalRuns == innings1.totalRuns -> {
                "Match Tied (${innings1.totalRuns} - ${innings2.totalRuns})"
            }
            else -> {
                val runMargin = innings1.totalRuns - innings2.totalRuns
                val unit = if (runMargin == 1) "run" else "runs"
                "${innings1.battingTeam.name} won by $runMargin $unit"
            }
        }
    }

    private fun formatDismissal(
        wicketType: WicketType,
        bowlerName: String,
        fielderName: String?
    ): String {
        return when (wicketType) {
            WicketType.BOWLED -> "b $bowlerName"
            WicketType.CAUGHT -> if (!fielderName.isNullOrBlank()) "c $fielderName b $bowlerName" else "c & b $bowlerName"
            WicketType.LBW -> "lbw b $bowlerName"
            WicketType.RUN_OUT -> if (!fielderName.isNullOrBlank()) "run out ($fielderName)" else "run out"
            WicketType.STUMPED -> if (!fielderName.isNullOrBlank()) "st $fielderName b $bowlerName" else "st b $bowlerName"
            WicketType.HIT_WICKET -> "hit wicket b $bowlerName"
            WicketType.NONE -> "out"
        }
    }
}
