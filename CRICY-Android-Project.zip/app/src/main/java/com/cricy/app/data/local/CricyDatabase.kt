package com.cricy.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.cricy.app.data.local.dao.DeliveryDao
import com.cricy.app.data.local.dao.MatchDao
import com.cricy.app.data.local.dao.PlayerDao
import com.cricy.app.data.local.dao.TeamDao
import com.cricy.app.data.local.entity.DeliveryEntity
import com.cricy.app.data.local.entity.MatchEntity
import com.cricy.app.data.local.entity.PlayerEntity
import com.cricy.app.data.local.entity.TeamEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        TeamEntity::class,
        PlayerEntity::class,
        MatchEntity::class,
        DeliveryEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class CricyDatabase : RoomDatabase() {
    abstract fun teamDao(): TeamDao
    abstract fun playerDao(): PlayerDao
    abstract fun matchDao(): MatchDao
    abstract fun deliveryDao(): DeliveryDao

    companion object {
        @Volatile
        private var INSTANCE: CricyDatabase? = null

        fun getInstance(context: Context): CricyDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(appContext: Context): CricyDatabase {
            return Room.databaseBuilder(
                appContext,
                CricyDatabase::class.java,
                "cricy_local.db"
            )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            seedStarterClubTeams(getInstance(appContext))
                        }
                    }
                })
                .build()
        }

        private suspend fun seedStarterClubTeams(database: CricyDatabase) {
            if (database.teamDao().countTeams() > 0) return

            val silverStrikersId = database.teamDao().insertTeam(
                TeamEntity(
                    name = "Silver Strikers",
                    shortName = "SLV",
                    accentHex = "#D0D6DF"
                )
            )
            val goldRoyalsId = database.teamDao().insertTeam(
                TeamEntity(
                    name = "Gold Royals",
                    shortName = "GLD",
                    accentHex = "#D4AF37"
                )
            )

            val strikersRoster = listOf(
                PlayerEntity(teamId = silverStrikersId, name = "Aarav Sharma", role = "BATTER", battingStyle = "Right-Hand Bat", bowlingStyle = "Right-Arm Offbreak", jerseyNumber = 7),
                PlayerEntity(teamId = silverStrikersId, name = "Rohan Verma", role = "WICKET_KEEPER", battingStyle = "Left-Hand Bat", bowlingStyle = "None", jerseyNumber = 18),
                PlayerEntity(teamId = silverStrikersId, name = "Kabir Patel", role = "BATTER", battingStyle = "Right-Hand Bat", bowlingStyle = "Right-Arm Medium", jerseyNumber = 45),
                PlayerEntity(teamId = silverStrikersId, name = "Vikram Nair", role = "ALL_ROUNDER", battingStyle = "Left-Hand Bat", bowlingStyle = "Left-Arm Orthodox", jerseyNumber = 12),
                PlayerEntity(teamId = silverStrikersId, name = "Devansh Rao", role = "ALL_ROUNDER", battingStyle = "Right-Hand Bat", bowlingStyle = "Right-Arm Fast-Medium", jerseyNumber = 33),
                PlayerEntity(teamId = silverStrikersId, name = "Siddharth Gill", role = "BATTER", battingStyle = "Right-Hand Bat", bowlingStyle = "None", jerseyNumber = 10),
                PlayerEntity(teamId = silverStrikersId, name = "Arjun Kulkarni", role = "ALL_ROUNDER", battingStyle = "Right-Hand Bat", bowlingStyle = "Right-Arm Legbreak", jerseyNumber = 24),
                PlayerEntity(teamId = silverStrikersId, name = "Nikhil Joshi", role = "BOWLER", battingStyle = "Right-Hand Bat", bowlingStyle = "Right-Arm Fast", jerseyNumber = 93),
                PlayerEntity(teamId = silverStrikersId, name = "Pranav Iyer", role = "BOWLER", battingStyle = "Left-Hand Bat", bowlingStyle = "Left-Arm Fast-Medium", jerseyNumber = 19),
                PlayerEntity(teamId = silverStrikersId, name = "Harshvardhan Das", role = "BOWLER", battingStyle = "Right-Hand Bat", bowlingStyle = "Right-Arm Offbreak", jerseyNumber = 99),
                PlayerEntity(teamId = silverStrikersId, name = "Manav Mehta", role = "BOWLER", battingStyle = "Right-Hand Bat", bowlingStyle = "Right-Arm Fast", jerseyNumber = 14)
            )

            val royalsRoster = listOf(
                PlayerEntity(teamId = goldRoyalsId, name = "Zaid Khan", role = "BATTER", battingStyle = "Left-Hand Bat", bowlingStyle = "Right-Arm Offbreak", jerseyNumber = 9),
                PlayerEntity(teamId = goldRoyalsId, name = "Aditya Kapoor", role = "BATTER", battingStyle = "Right-Hand Bat", bowlingStyle = "None", jerseyNumber = 17),
                PlayerEntity(teamId = goldRoyalsId, name = "Ishaan Malhotra", role = "WICKET_KEEPER", battingStyle = "Right-Hand Bat", bowlingStyle = "None", jerseyNumber = 1),
                PlayerEntity(teamId = goldRoyalsId, name = "Raghavendra Singh", role = "ALL_ROUNDER", battingStyle = "Right-Hand Bat", bowlingStyle = "Right-Arm Fast-Medium", jerseyNumber = 8),
                PlayerEntity(teamId = goldRoyalsId, name = "Yashwardhan Tiwari", role = "ALL_ROUNDER", battingStyle = "Left-Hand Bat", bowlingStyle = "Left-Arm Orthodox", jerseyNumber = 23),
                PlayerEntity(teamId = goldRoyalsId, name = "Tanmay Deshmukh", role = "BATTER", battingStyle = "Right-Hand Bat", bowlingStyle = "Right-Arm Medium", jerseyNumber = 21),
                PlayerEntity(teamId = goldRoyalsId, name = "Karanvir Bedi", role = "ALL_ROUNDER", battingStyle = "Right-Hand Bat", bowlingStyle = "Right-Arm Legbreak", jerseyNumber = 5),
                PlayerEntity(teamId = goldRoyalsId, name = "Samarth Menon", role = "BOWLER", battingStyle = "Right-Hand Bat", bowlingStyle = "Right-Arm Fast", jerseyNumber = 11),
                PlayerEntity(teamId = goldRoyalsId, name = "Farhan Qureshi", role = "BOWLER", battingStyle = "Left-Hand Bat", bowlingStyle = "Left-Arm Fast", jerseyNumber = 77),
                PlayerEntity(teamId = goldRoyalsId, name = "Anirudh Bhat", role = "BOWLER", battingStyle = "Right-Hand Bat", bowlingStyle = "Right-Arm Legbreak", jerseyNumber = 88),
                PlayerEntity(teamId = goldRoyalsId, name = "Dhruv Chauhan", role = "BOWLER", battingStyle = "Right-Hand Bat", bowlingStyle = "Right-Arm Medium", jerseyNumber = 55)
            )

            database.playerDao().insertPlayers(strikersRoster + royalsRoster)
        }
    }
}
