package com.cricy.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricy.app.data.local.entity.PlayerEntity
import com.cricy.app.data.local.entity.TeamEntity
import com.cricy.app.ui.components.CricyTopBar
import com.cricy.app.ui.components.GoldHighlightButton
import com.cricy.app.ui.components.MetallicCard
import com.cricy.app.ui.components.MetallicSilverButton
import com.cricy.app.ui.components.PlayerAvatar
import com.cricy.app.ui.theme.CricyBlack
import com.cricy.app.ui.theme.CricySurface
import com.cricy.app.ui.theme.CricySurfaceBorder
import com.cricy.app.ui.theme.CricySurfaceElevated
import com.cricy.app.ui.theme.GoldBright
import com.cricy.app.ui.theme.GoldPrimary
import com.cricy.app.ui.theme.SilverBright
import com.cricy.app.ui.theme.SilverMid
import com.cricy.app.ui.theme.WicketCrimson
import com.cricy.app.ui.viewmodel.TeamsAndPlayersViewModel
import kotlinx.coroutines.launch

@Composable
fun PlayersScreen(
    viewModel: TeamsAndPlayersViewModel,
    initialTeamFilterId: Long? = null,
    onBack: () -> Unit,
    onOpenPlayerProfile: (Long) -> Unit
) {
    val teams by viewModel.teams.collectAsState()
    val players by viewModel.players.collectAsState()
    val teamMap = remember(teams) { teams.associateBy { it.id } }

    var selectedTeamFilter by remember(initialTeamFilterId) { mutableStateOf(initialTeamFilterId) }
    var searchQuery by remember { mutableStateOf("") }
    var showPlayerDialog by remember { mutableStateOf(false) }
    var editingPlayer by remember { mutableStateOf<PlayerEntity?>(null) }

    val filteredPlayers = remember(players, selectedTeamFilter, searchQuery) {
        players.filter { p ->
            (selectedTeamFilter == null || p.teamId == selectedTeamFilter) &&
                (searchQuery.isBlank() || p.name.contains(searchQuery, ignoreCase = true))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CricyBlack)
            .systemBarsPadding()
    ) {
        CricyTopBar(
            title = "My Players",
            subtitle = "${players.size} REGISTERED PLAYERS",
            onBack = onBack,
            trailingAction = {
                IconButton(onClick = {
                    editingPlayer = null
                    showPlayerDialog = true
                }) {
                    Icon(Icons.Default.Add, contentDescription = "Add Player", tint = GoldBright)
                }
            }
        )

        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search players...", color = SilverMid) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SilverMid) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = CricySurfaceBorder,
                    focusedTextColor = SilverBright,
                    unfocusedTextColor = SilverBright
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChipButton(
                    label = "All Teams",
                    selected = selectedTeamFilter == null,
                    onClick = { selectedTeamFilter = null }
                )
                teams.forEach { team ->
                    FilterChipButton(
                        label = team.shortName,
                        selected = selectedTeamFilter == team.id,
                        onClick = { selectedTeamFilter = team.id }
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredPlayers, key = { it.id }) { player ->
                val team = teamMap[player.teamId]
                MetallicCard(
                    onClick = { onOpenPlayerProfile(player.id) },
                    contentPadding = PaddingValues(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlayerAvatar(
                            name = player.name,
                            photoUri = player.photoUri,
                            size = 54.dp,
                            goldRing = player.role == "ALL_ROUNDER" || player.role == "WICKET_KEEPER"
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = player.name,
                                color = SilverBright,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${team?.shortName ?: "CLUB"} · ${player.role.replace("_", " ")} · #${player.jerseyNumber}",
                                color = GoldPrimary,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${player.battingStyle} · Tap for career stats",
                                color = SilverMid,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = {
                            editingPlayer = player
                            showPlayerDialog = true
                        }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Player", tint = SilverMid)
                        }
                        IconButton(onClick = { viewModel.deletePlayer(player) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Player", tint = WicketCrimson)
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.padding(16.dp)) {
            GoldHighlightButton(
                text = "Add Player",
                icon = Icons.Default.Add,
                enabled = teams.isNotEmpty(),
                onClick = {
                    editingPlayer = null
                    showPlayerDialog = true
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    if (showPlayerDialog && teams.isNotEmpty()) {
        PlayerEditorDialog(
            initial = editingPlayer,
            teams = teams,
            defaultTeamId = selectedTeamFilter ?: teams.first().id,
            onPersistPhoto = { uri -> viewModel.persistPhoto(uri) },
            onDismiss = { showPlayerDialog = false },
            onSave = { teamId, name, role, batStyle, bowlStyle, jersey, photoUri ->
                viewModel.savePlayer(
                    existingId = editingPlayer?.id ?: 0L,
                    teamId = teamId,
                    name = name,
                    role = role,
                    battingStyle = batStyle,
                    bowlingStyle = bowlStyle,
                    jerseyNumber = jersey,
                    photoUri = photoUri
                )
                showPlayerDialog = false
            }
        )
    }
}

@Composable
private fun FilterChipButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) GoldPrimary.copy(alpha = 0.22f) else CricySurfaceElevated)
            .border(1.dp, if (selected) GoldBright else CricySurfaceBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            color = if (selected) GoldBright else SilverBright,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerEditorDialog(
    initial: PlayerEntity?,
    teams: List<TeamEntity>,
    defaultTeamId: Long,
    onPersistPhoto: suspend (android.net.Uri) -> String?,
    onDismiss: () -> Unit,
    onSave: (Long, String, String, String, String, Int, String?) -> Unit
) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var selectedTeamId by remember { mutableStateOf(initial?.teamId ?: defaultTeamId) }
    var role by remember { mutableStateOf(initial?.role ?: "ALL_ROUNDER") }
    var batStyle by remember { mutableStateOf(initial?.battingStyle ?: "Right-Hand Bat") }
    var bowlStyle by remember { mutableStateOf(initial?.bowlingStyle ?: "Right-Arm Medium") }
    var jerseyText by remember { mutableStateOf((initial?.jerseyNumber ?: 0).takeIf { it > 0 }?.toString() ?: "") }
    var photoUri by remember { mutableStateOf(initial?.photoUri) }
    var teamDropdownExpanded by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val persisted = onPersistPhoto(uri)
                if (persisted != null) {
                    photoUri = persisted
                }
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CricySurface,
        title = {
            Text(
                text = if (initial == null) "Add Player" else "Edit Player",
                color = SilverBright,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PlayerAvatar(name = name.ifBlank { "P" }, photoUri = photoUri, size = 60.dp, goldRing = true)
                    MetallicSilverButton(
                        text = if (photoUri == null) "Pick Photo" else "Change Photo",
                        icon = Icons.Default.CameraAlt,
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = CricySurfaceBorder,
                        focusedTextColor = SilverBright,
                        unfocusedTextColor = SilverBright
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                ExposedDropdownMenuBox(
                    expanded = teamDropdownExpanded,
                    onExpandedChange = { teamDropdownExpanded = !teamDropdownExpanded }
                ) {
                    val teamName = teams.firstOrNull { it.id == selectedTeamId }?.name ?: "Select Team"
                    OutlinedTextField(
                        value = teamName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Team") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = teamDropdownExpanded) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = CricySurfaceBorder,
                            focusedTextColor = SilverBright,
                            unfocusedTextColor = SilverBright
                        ),
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = teamDropdownExpanded,
                        onDismissRequest = { teamDropdownExpanded = false },
                        modifier = Modifier.background(CricySurfaceElevated)
                    ) {
                        teams.forEach { t ->
                            DropdownMenuItem(
                                text = { Text(t.name, color = SilverBright) },
                                onClick = {
                                    selectedTeamId = t.id
                                    teamDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("BATTER", "BOWLER", "ALL_ROUNDER", "WICKET_KEEPER").forEach { r ->
                        FilterChipButton(
                            label = r.replace("_", " "),
                            selected = role == r,
                            onClick = { role = r }
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = jerseyText,
                        onValueChange = { jerseyText = it.filter { c -> c.isDigit() }.take(3) },
                        label = { Text("Jersey #") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = CricySurfaceBorder,
                            focusedTextColor = SilverBright,
                            unfocusedTextColor = SilverBright
                        ),
                        modifier = Modifier.weight(0.4f)
                    )
                    OutlinedTextField(
                        value = batStyle,
                        onValueChange = { batStyle = it },
                        label = { Text("Batting Style") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = CricySurfaceBorder,
                            focusedTextColor = SilverBright,
                            unfocusedTextColor = SilverBright
                        ),
                        modifier = Modifier.weight(0.6f)
                    )
                }

                OutlinedTextField(
                    value = bowlStyle,
                    onValueChange = { bowlStyle = it },
                    label = { Text("Bowling Style") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = CricySurfaceBorder,
                        focusedTextColor = SilverBright,
                        unfocusedTextColor = SilverBright
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            GoldHighlightButton(
                text = "Save",
                enabled = name.isNotBlank(),
                onClick = {
                    onSave(
                        selectedTeamId,
                        name,
                        role,
                        batStyle,
                        bowlStyle,
                        jerseyText.toIntOrNull() ?: 0,
                        photoUri
                    )
                },
                modifier = Modifier.width(100.dp)
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SilverMid)
            }
        }
    )
}
