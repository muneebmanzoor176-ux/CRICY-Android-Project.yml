package com.cricy.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricy.app.ui.components.CricyTopBar
import com.cricy.app.ui.components.GoldHighlightButton
import com.cricy.app.ui.components.MetallicCard
import com.cricy.app.ui.theme.CricyBlack
import com.cricy.app.ui.theme.CricySurfaceBorder
import com.cricy.app.ui.theme.CricySurfaceElevated
import com.cricy.app.ui.theme.GoldBright
import com.cricy.app.ui.theme.GoldPrimary
import com.cricy.app.ui.theme.SilverBright
import com.cricy.app.ui.theme.SilverMid
import com.cricy.app.ui.viewmodel.SettingsViewModel

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()
    var scorerNameInput by remember(settings.scorerName) { mutableStateOf(settings.scorerName) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CricyBlack)
            .systemBarsPadding()
    ) {
        CricyTopBar(
            title = "Settings",
            subtitle = "SCORING & PREFERENCES",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                MetallicCard(goldHighlight = true) {
                    Text(
                        text = "SCORER IDENTITY",
                        color = GoldPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = scorerNameInput,
                        onValueChange = { scorerNameInput = it },
                        label = { Text("Scorer / Club Name") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = CricySurfaceBorder,
                            focusedTextColor = SilverBright,
                            unfocusedTextColor = SilverBright
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    GoldHighlightButton(
                        text = "Save Scorer Name",
                        onClick = { viewModel.setScorerName(scorerNameInput) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            item {
                MetallicCard {
                    Text(
                        text = "DEFAULT MATCH FORMAT",
                        color = GoldPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("T20", "ODI", "CUSTOM").forEach { fmt ->
                            val selected = settings.defaultFormat == fmt
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selected) GoldPrimary.copy(alpha = 0.22f) else CricySurfaceElevated)
                                    .border(1.dp, if (selected) GoldBright else CricySurfaceBorder, RoundedCornerShape(10.dp))
                                    .clickable { viewModel.setDefaultFormat(fmt) }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = fmt,
                                    color = if (selected) GoldBright else SilverBright,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }

            item {
                MetallicCard {
                    Text(
                        text = "SCORING EXPERIENCE",
                        color = GoldPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    SettingToggleRow(
                        title = "Haptic Key Feedback",
                        subtitle = "Vibrate subtly on every ball tap",
                        checked = settings.hapticFeedbackEnabled,
                        onCheckedChange = viewModel::setHapticFeedback
                    )
                    Spacer(Modifier.height(8.dp))
                    SettingToggleRow(
                        title = "Celebration Animations",
                        subtitle = "Show 4, 6, and Wicket broadcast overlays",
                        checked = settings.celebrationAnimationsEnabled,
                        onCheckedChange = viewModel::setCelebrationAnimations
                    )
                    Spacer(Modifier.height(8.dp))
                    SettingToggleRow(
                        title = "Confirm Before Undo",
                        subtitle = "Ask confirmation before reverting last ball",
                        checked = settings.confirmUndoEnabled,
                        onCheckedChange = viewModel::setConfirmUndo
                    )
                }
            }

            item {
                MetallicCard {
                    Text(
                        text = "OFFLINE RELIABILITY",
                        color = GoldPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "CRICY stores every delivery, player profile, and statistic locally in an on-device Room database. Matches work 100% offline and resume automatically after closing the app.",
                        color = SilverMid,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = SilverBright, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, color = SilverMid, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = CricyBlack,
                checkedTrackColor = GoldBright,
                uncheckedThumbColor = SilverMid,
                uncheckedTrackColor = CricySurfaceElevated
            )
        )
    }
}
