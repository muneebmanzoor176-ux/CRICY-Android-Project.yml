package com.cricy.app.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.cricyDataStore: DataStore<Preferences> by preferencesDataStore(name = "cricy_settings")

data class CricySettings(
    val hapticFeedbackEnabled: Boolean = true,
    val celebrationAnimationsEnabled: Boolean = true,
    val confirmUndoEnabled: Boolean = false,
    val defaultFormat: String = "T20",
    val defaultCustomOvers: Int = 10,
    val scorerName: String = "Club Scorer"
)

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val HAPTICS = booleanPreferencesKey("haptic_feedback")
        val ANIMATIONS = booleanPreferencesKey("celebration_animations")
        val CONFIRM_UNDO = booleanPreferencesKey("confirm_undo")
        val DEFAULT_FORMAT = stringPreferencesKey("default_format")
        val DEFAULT_CUSTOM_OVERS = intPreferencesKey("default_custom_overs")
        val SCORER_NAME = stringPreferencesKey("scorer_name")
    }

    val settingsFlow: Flow<CricySettings> = context.cricyDataStore.data.map { prefs ->
        CricySettings(
            hapticFeedbackEnabled = prefs[Keys.HAPTICS] ?: true,
            celebrationAnimationsEnabled = prefs[Keys.ANIMATIONS] ?: true,
            confirmUndoEnabled = prefs[Keys.CONFIRM_UNDO] ?: false,
            defaultFormat = prefs[Keys.DEFAULT_FORMAT] ?: "T20",
            defaultCustomOvers = prefs[Keys.DEFAULT_CUSTOM_OVERS] ?: 10,
            scorerName = prefs[Keys.SCORER_NAME] ?: "Club Scorer"
        )
    }

    suspend fun setHapticFeedback(enabled: Boolean) {
        context.cricyDataStore.edit { it[Keys.HAPTICS] = enabled }
    }

    suspend fun setCelebrationAnimations(enabled: Boolean) {
        context.cricyDataStore.edit { it[Keys.ANIMATIONS] = enabled }
    }

    suspend fun setConfirmUndo(enabled: Boolean) {
        context.cricyDataStore.edit { it[Keys.CONFIRM_UNDO] = enabled }
    }

    suspend fun setDefaultFormat(format: String) {
        context.cricyDataStore.edit { it[Keys.DEFAULT_FORMAT] = format }
    }

    suspend fun setDefaultCustomOvers(overs: Int) {
        context.cricyDataStore.edit { it[Keys.DEFAULT_CUSTOM_OVERS] = overs.coerceIn(1, 99) }
    }

    suspend fun setScorerName(name: String) {
        context.cricyDataStore.edit { it[Keys.SCORER_NAME] = name.ifBlank { "Club Scorer" } }
    }
}
