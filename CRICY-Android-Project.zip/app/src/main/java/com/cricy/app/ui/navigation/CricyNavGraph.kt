package com.cricy.app.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.cricy.app.data.repository.CricyRepository
import com.cricy.app.ui.screens.HomeScreen
import com.cricy.app.ui.screens.LiveScoringScreen
import com.cricy.app.ui.screens.MatchHistoryScreen
import com.cricy.app.ui.screens.NewMatchScreen
import com.cricy.app.ui.screens.PlayerProfileScreen
import com.cricy.app.ui.screens.PlayersScreen
import com.cricy.app.ui.screens.ScorecardScreen
import com.cricy.app.ui.screens.SettingsScreen
import com.cricy.app.ui.screens.SplashScreen
import com.cricy.app.ui.screens.StatisticsScreen
import com.cricy.app.ui.screens.TeamsScreen
import com.cricy.app.ui.viewmodel.CricyViewModelFactory
import com.cricy.app.ui.viewmodel.HomeViewModel
import com.cricy.app.ui.viewmodel.LiveScoringViewModel
import com.cricy.app.ui.viewmodel.MatchHistoryViewModel
import com.cricy.app.ui.viewmodel.NewMatchViewModel
import com.cricy.app.ui.viewmodel.PlayerProfileViewModel
import com.cricy.app.ui.viewmodel.ScorecardViewModel
import com.cricy.app.ui.viewmodel.SettingsViewModel
import com.cricy.app.ui.viewmodel.StatisticsViewModel
import com.cricy.app.ui.viewmodel.TeamsAndPlayersViewModel

object CricyRoutes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val NEW_MATCH = "new_match"
    const val LIVE_SCORING = "live_scoring/{matchId}"
    const val SCORECARD = "scorecard/{matchId}"
    const val MATCH_HISTORY = "match_history"
    const val TEAMS = "teams"
    const val PLAYERS = "players?teamId={teamId}"
    const val PLAYER_PROFILE = "player_profile/{playerId}"
    const val STATISTICS = "statistics"
    const val SETTINGS = "settings"

    fun liveScoring(matchId: Long) = "live_scoring/$matchId"
    fun scorecard(matchId: Long) = "scorecard/$matchId"
    fun players(teamId: Long? = null) = if (teamId != null) "players?teamId=$teamId" else "players?teamId=-1"
    fun playerProfile(playerId: Long) = "player_profile/$playerId"
}

@Composable
fun CricyNavGraph(repository: CricyRepository) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = CricyRoutes.SPLASH,
        enterTransition = {
            slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Left, tween(240)) + fadeIn(tween(220))
        },
        exitTransition = {
            fadeOut(tween(180))
        },
        popEnterTransition = {
            slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Right, tween(240)) + fadeIn(tween(220))
        },
        popExitTransition = {
            fadeOut(tween(180))
        }
    ) {
        composable(CricyRoutes.SPLASH) {
            SplashScreen(
                onFinished = {
                    navController.navigate(CricyRoutes.HOME) {
                        popUpTo(CricyRoutes.SPLASH) { inclusive = true }
                    }
                }
            )
        }

        composable(CricyRoutes.HOME) {
            val vm: HomeViewModel = viewModel(factory = CricyViewModelFactory(repository))
            HomeScreen(
                viewModel = vm,
                onNewMatch = { navController.navigate(CricyRoutes.NEW_MATCH) },
                onContinueMatch = { matchId -> navController.navigate(CricyRoutes.liveScoring(matchId)) },
                onMatchHistory = { navController.navigate(CricyRoutes.MATCH_HISTORY) },
                onMyTeams = { navController.navigate(CricyRoutes.TEAMS) },
                onMyPlayers = { navController.navigate(CricyRoutes.players()) },
                onStatistics = { navController.navigate(CricyRoutes.STATISTICS) },
                onSettings = { navController.navigate(CricyRoutes.SETTINGS) }
            )
        }

        composable(CricyRoutes.NEW_MATCH) {
            val vm: NewMatchViewModel = viewModel(factory = CricyViewModelFactory(repository))
            NewMatchScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onManageTeams = { navController.navigate(CricyRoutes.TEAMS) },
                onMatchCreated = { matchId ->
                    navController.navigate(CricyRoutes.liveScoring(matchId)) {
                        popUpTo(CricyRoutes.HOME)
                    }
                }
            )
        }

        composable(
            route = CricyRoutes.LIVE_SCORING,
            arguments = listOf(navArgument("matchId") { type = NavType.LongType })
        ) { backStackEntry ->
            val matchId = backStackEntry.arguments?.getLong("matchId") ?: 0L
            val vm: LiveScoringViewModel = viewModel(factory = CricyViewModelFactory(repository, matchId))
            LiveScoringScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onOpenScorecard = { id -> navController.navigate(CricyRoutes.scorecard(id)) }
            )
        }

        composable(
            route = CricyRoutes.SCORECARD,
            arguments = listOf(navArgument("matchId") { type = NavType.LongType })
        ) { backStackEntry ->
            val matchId = backStackEntry.arguments?.getLong("matchId") ?: 0L
            val vm: ScorecardViewModel = viewModel(factory = CricyViewModelFactory(repository, matchId))
            ScorecardScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onOpenPlayerProfile = { pid -> navController.navigate(CricyRoutes.playerProfile(pid)) }
            )
        }

        composable(CricyRoutes.MATCH_HISTORY) {
            val vm: MatchHistoryViewModel = viewModel(factory = CricyViewModelFactory(repository))
            MatchHistoryScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onResumeMatch = { id -> navController.navigate(CricyRoutes.liveScoring(id)) },
                onOpenScorecard = { id -> navController.navigate(CricyRoutes.scorecard(id)) }
            )
        }

        composable(CricyRoutes.TEAMS) {
            val vm: TeamsAndPlayersViewModel = viewModel(factory = CricyViewModelFactory(repository))
            TeamsScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onOpenTeamPlayers = { teamId -> navController.navigate(CricyRoutes.players(teamId)) }
            )
        }

        composable(
            route = CricyRoutes.PLAYERS,
            arguments = listOf(navArgument("teamId") { type = NavType.LongType; defaultValue = -1L })
        ) { backStackEntry ->
            val teamIdArg = backStackEntry.arguments?.getLong("teamId") ?: -1L
            val vm: TeamsAndPlayersViewModel = viewModel(factory = CricyViewModelFactory(repository))
            PlayersScreen(
                viewModel = vm,
                initialTeamFilterId = teamIdArg.takeIf { it > 0L },
                onBack = { navController.popBackStack() },
                onOpenPlayerProfile = { pid -> navController.navigate(CricyRoutes.playerProfile(pid)) }
            )
        }

        composable(
            route = CricyRoutes.PLAYER_PROFILE,
            arguments = listOf(navArgument("playerId") { type = NavType.LongType })
        ) { backStackEntry ->
            val playerId = backStackEntry.arguments?.getLong("playerId") ?: 0L
            val vm: PlayerProfileViewModel = viewModel(factory = CricyViewModelFactory(repository, playerId))
            PlayerProfileScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() }
            )
        }

        composable(CricyRoutes.STATISTICS) {
            val vm: StatisticsViewModel = viewModel(factory = CricyViewModelFactory(repository))
            StatisticsScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() },
                onOpenPlayerProfile = { pid -> navController.navigate(CricyRoutes.playerProfile(pid)) }
            )
        }

        composable(CricyRoutes.SETTINGS) {
            val vm: SettingsViewModel = viewModel(factory = CricyViewModelFactory(repository))
            SettingsScreen(
                viewModel = vm,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
