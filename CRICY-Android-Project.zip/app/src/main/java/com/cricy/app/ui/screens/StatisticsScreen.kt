package com.cricy.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricy.app.domain.model.PlayerCareerStats
import com.cricy.app.ui.components.CricyTopBar
import com.cricy.app.ui.components.MetallicCard
import com.cricy.app.ui.components.PlayerAvatar
import com.cricy.app.ui.theme.CricyBlack
import com.cricy.app.ui.theme.CricySurfaceBorder
import com.cricy.app.ui.theme.CricySurfaceElevated
import com.cricy.app.ui.theme.GoldBright
import com.cricy.app.ui.theme.GoldPrimary
import com.cricy.app.ui.theme.SilverBright
import com.cricy.app.ui.theme.SilverMid
import com.cricy.app.ui.viewmodel.StatisticsViewModel
import java.util.Locale

@Composable
fun StatisticsScreen(
    viewModel: StatisticsViewModel,
    onBack: () -> Unit,
    onOpenPlayerProfile: (Long) -> Unit
) {
    val allStats by viewModel.playerStats.collectAsState()
    val teams by viewModel.teams.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Batting, 1 = Bowling
    var selectedTeamId by remember { mutableStateOf<Long?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    val filtered = remember(allStats, selectedTab, selectedTeamId, searchQuery) {
        allStats
            .filter { stat ->
                (selectedTeamId == null || stat.player.teamId == selectedTeamId) &&
                    (searchQuery.isBlank() || stat.player.name.contains(searchQuery, ignoreCase = true))
            }
            .sortedWith(
                if (selectedTab == 0) {
                    compareByDescending<PlayerCareerStats> { it.runsScored }
                        .thenByDescending { it.strikeRate }
                } else {
                    compareByDescending<PlayerCareerStats> { it.wicketsTaken }
                        .thenBy { if (it.legalBallsBowled > 0) it.economyRate else Double.MAX_VALUE }
                }
            )
    }

    val topBatter = allStats.maxByOrNull { it.runsScored }?.takeIf { it.runsScored > 0 }
    val topBowler = allStats.maxByOrNull { it.wicketsTaken }?.takeIf { it.wicketsTaken > 0 }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CricyBlack)
            .systemBarsPadding()
    ) {
        CricyTopBar(
            title = "Player Statistics",
            subtitle = "LIVE CAREER BATTING & BOWLING",
            onBack = onBack
        )

        Column(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Top Leaders Highlight Strip
            if (topBatter != null || topBowler != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    topBatter?.let { b ->
                        MetallicCard(
                            goldHighlight = true,
                            onClick = { onOpenPlayerProfile(b.player.id) },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(12.dp)
                        ) {
                            Text("MOST RUNS", color = GoldBright, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(b.player.name, color = SilverBright, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${b.runsScored} runs · SR ${String.format(Locale.US, "%.1f", b.strikeRate)}", color = SilverMid, fontSize = 11.sp)
                        }
                    }
                    topBowler?.let { bw ->
                        MetallicCard(
                            goldHighlight = true,
                            onClick = { onOpenPlayerProfile(bw.player.id) },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(12.dp)
                        ) {
                            Text("MOST WICKETS", color = GoldBright, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(bw.player.name, color = SilverBright, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${bw.wicketsTaken} wkts · Best ${bw.bestFiguresDisplay}", color = SilverMid, fontSize = 11.sp)
                        }
                    }
                }
            }

            // Batting / Bowling Segmented Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(0 to "Batting Stats", 1 to "Bowling Stats").forEach { (idx, label) ->
                    val selected = selectedTab == idx
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (selected) GoldPrimary.copy(alpha = 0.22f) else CricySurfaceElevated)
                            .border(1.dp, if (selected) GoldBright else CricySurfaceBorder, RoundedCornerShape(10.dp))
                            .clickable { selectedTab = idx }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            color = if (selected) GoldBright else SilverBright,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search player stats...", color = SilverMid) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SilverMid) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = CricySurfaceBorder,
                    focusedTextColor = SilverBright,
                    unfocusedTextColor = SilverBright
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatFilterChip(
                    label = "All Teams",
                    selected = selectedTeamId == null,
                    onClick = { selectedTeamId = null }
                )
                teams.forEach { t ->
                    StatFilterChip(
                        label = t.shortName,
                        selected = selectedTeamId == t.id,
                        onClick = { selectedTeamId = t.id }
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            itemsIndexed(filtered, key = { _, item -> item.player.id }) { index, stat ->
                MetallicCard(
                    onClick = { onOpenPlayerProfile(stat.player.id) },
                    contentPadding = PaddingValues(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "#${index + 1}",
                            color = if (index < 3) GoldBright else SilverMid,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp,
                            modifier = Modifier.width(28.dp)
                        )
                        PlayerAvatar(
                            name = stat.player.name,
                            photoUri = stat.player.photoUri,
                            size = 44.dp,
                            goldRing = index == 0
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stat.player.name,
                                color = SilverBright,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${stat.team?.shortName ?: "CLUB"} · ${stat.matchesPlayed} matches",
                                color = SilverMid,
                                fontSize = 11.sp
                            )
                        }
                        if (selectedTab == 0) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${stat.runsScored} runs",
                                    color = GoldBright,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "HS ${stat.highestScoreDisplay} · SR ${String.format(Locale.US, "%.1f", stat.strikeRate)}",
                                    color = SilverMid,
                                    fontSize = 11.sp
                                )
                            }
                        } else {
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${stat.wicketsTaken} wkts",
                                    color = GoldBright,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "Best ${stat.bestFiguresDisplay} · Econ ${String.format(Locale.US, "%.2f", stat.economyRate)}",
                                    color = SilverMid,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    if (selectedTab == 0) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            MiniStat("Inn", stat.inningsBatted.toString())
                            MiniStat("Avg", stat.battingAverage?.let { String.format(Locale.US, "%.1f", it) } ?: "--")
                            MiniStat("SR", String.format(Locale.US, "%.1f", stat.strikeRate))
                            MiniStat("100s", stat.centuries.toString())
                            MiniStat("50s", stat.fifties.toString())
                            MiniStat("4s/6s", "${stat.fours}/${stat.sixes}")
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            MiniStat("Ov", stat.oversBowledDisplay)
                            MiniStat("Mdn", stat.maidens.toString())
                            MiniStat("Runs", stat.runsConceded.toString())
                            MiniStat("Avg", stat.bowlingAverage?.let { String.format(Locale.US, "%.1f", it) } ?: "--")
                            MiniStat("Econ", String.format(Locale.US, "%.2f", stat.economyRate))
                            MiniStat("Best", stat.bestFiguresDisplay)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatFilterChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) GoldPrimary.copy(alpha = 0.22f) else CricySurfaceElevated)
            .border(1.dp, if (selected) GoldBright else CricySurfaceBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(label, color = if (selected) GoldBright else SilverBright, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun MiniStat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = SilverBright, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text(label, color = SilverMid, fontSize = 10.sp)
    }
}
