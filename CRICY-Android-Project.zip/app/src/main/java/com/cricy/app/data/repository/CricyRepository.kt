package com.cricy.app.data.repository

import android.content.Context
import android.net.Uri
import com.cricy.app.data.local.CricyDatabase
import com.cricy.app.data.local.entity.DeliveryEntity
import com.cricy.app.data.local.entity.MatchEntity
import com.cricy.app.data.local.entity.PlayerEntity
import com.cricy.app.data.local.entity.TeamEntity
import com.cricy.app.data.preferences.CricySettings
import com.cricy.app.data.preferences.SettingsDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class CricyRepository(
    private val context: Context,
    private val database: CricyDatabase,
    private val settingsDataStore: SettingsDataStore
) {
    private val teamDao = database.teamDao()
    private val playerDao = database.playerDao()
    private val matchDao = database.matchDao()
    private val deliveryDao = database.deliveryDao()

    val settingsFlow: Flow<CricySettings> = settingsDataStore.settingsFlow

    fun observeAllTeams(): Flow<List<TeamEntity>> = teamDao.observeAllTeams()
    fun observeAllPlayers(): Flow<List<PlayerEntity>> = playerDao.observeAllPlayers()
    fun observePlayersByTeam(teamId: Long): Flow<List<PlayerEntity>> = playerDao.observePlayersByTeam(teamId)
    fun observePlayer(playerId: Long): Flow<PlayerEntity?> = playerDao.observePlayerById(playerId)
    fun observeAllMatches(): Flow<List<MatchEntity>> = matchDao.observeAllMatches()
    fun observeUnfinishedMatches(): Flow<List<MatchEntity>> = matchDao.observeUnfinishedMatches()
    fun observeMatch(matchId: Long): Flow<MatchEntity?> = matchDao.observeMatch(matchId)
    fun observeDeliveriesForMatch(matchId: Long): Flow<List<DeliveryEntity>> = deliveryDao.observeDeliveriesForMatch(matchId)
    fun observeAllDeliveries(): Flow<List<DeliveryEntity>> = deliveryDao.observeAllDeliveries()

    suspend fun createTeam(name: String, shortName: String, accentHex: String): Long {
        val cleanShort = shortName.trim().uppercase().take(4).ifEmpty {
            name.trim().take(3).uppercase()
        }
        return teamDao.insertTeam(
            TeamEntity(
                name = name.trim(),
                shortName = cleanShort,
                accentHex = accentHex
            )
        )
    }

    suspend fun updateTeam(team: TeamEntity) = teamDao.updateTeam(team)
    suspend fun deleteTeam(team: TeamEntity) = teamDao.deleteTeam(team)

    suspend fun savePlayer(player: PlayerEntity): Long {
        return if (player.id == 0L) {
            playerDao.insertPlayer(player)
        } else {
            playerDao.updatePlayer(player)
            player.id
        }
    }

    suspend fun deletePlayer(player: PlayerEntity) = playerDao.deletePlayer(player)

    /**
     * Copies a gallery image URI into app-internal storage so player profile photos
     * remain valid across app restarts and OS permission resets.
     */
    suspend fun persistPlayerPhoto(sourceUri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val photosDir = File(context.filesDir, "player_photos").apply {
                if (!exists()) mkdirs()
            }
            val destFile = File(photosDir, "player_${UUID.randomUUID()}.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext null
            Uri.fromFile(destFile).toString()
        } catch (_: Exception) {
            null
        }
    }

    suspend fun createMatch(match: MatchEntity): Long = matchDao.insertMatch(match)
    suspend fun getMatchById(matchId: Long): MatchEntity? = matchDao.getMatchById(matchId)
    suspend fun updateMatch(match: MatchEntity) = matchDao.updateMatch(match.copy(updatedAt = System.currentTimeMillis()))
    suspend fun deleteMatch(matchId: Long) = matchDao.deleteMatchById(matchId)

    suspend fun insertDelivery(delivery: DeliveryEntity): Long = deliveryDao.insertDelivery(delivery)
    suspend fun getDeliveriesOnce(matchId: Long): List<DeliveryEntity> = deliveryDao.getDeliveriesForMatchOnce(matchId)
    suspend fun getLastDeliveryInMatch(matchId: Long): DeliveryEntity? = deliveryDao.getLastDeliveryInMatch(matchId)
    suspend fun deleteDeliveryById(deliveryId: Long) = deliveryDao.deleteDeliveryById(deliveryId)

    suspend fun setHapticFeedback(enabled: Boolean) = settingsDataStore.setHapticFeedback(enabled)
    suspend fun setCelebrationAnimations(enabled: Boolean) = settingsDataStore.setCelebrationAnimations(enabled)
    suspend fun setConfirmUndo(enabled: Boolean) = settingsDataStore.setConfirmUndo(enabled)
    suspend fun setDefaultFormat(format: String) = settingsDataStore.setDefaultFormat(format)
    suspend fun setDefaultCustomOvers(overs: Int) = settingsDataStore.setDefaultCustomOvers(overs)
    suspend fun setScorerName(name: String) = settingsDataStore.setScorerName(name)
}
