package com.cricy.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricy.app.data.local.entity.TeamEntity
import com.cricy.app.ui.components.CricyTopBar
import com.cricy.app.ui.components.GoldHighlightButton
import com.cricy.app.ui.components.MetallicCard
import com.cricy.app.ui.components.MetallicSilverButton
import com.cricy.app.ui.theme.CricyBlack
import com.cricy.app.ui.theme.CricySurface
import com.cricy.app.ui.theme.CricySurfaceBorder
import com.cricy.app.ui.theme.CricySurfaceElevated
import com.cricy.app.ui.theme.GoldBright
import com.cricy.app.ui.theme.GoldPrimary
import com.cricy.app.ui.theme.SilverBright
import com.cricy.app.ui.theme.SilverMid
import com.cricy.app.ui.theme.WicketCrimson
import com.cricy.app.ui.viewmodel.TeamsAndPlayersViewModel

@Composable
fun TeamsScreen(
    viewModel: TeamsAndPlayersViewModel,
    onBack: () -> Unit,
    onOpenTeamPlayers: (Long) -> Unit
) {
    val teams by viewModel.teams.collectAsState()
    val players by viewModel.players.collectAsState()

    var showDialog by remember { mutableStateOf(false) }
    var editingTeam by remember { mutableStateOf<TeamEntity?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CricyBlack)
            .systemBarsPadding()
    ) {
        CricyTopBar(
            title = "My Teams",
            subtitle = "${teams.size} CUSTOM SQUADS",
            onBack = onBack,
            trailingAction = {
                IconButton(onClick = {
                    editingTeam = null
                    showDialog = true
                }) {
                    Icon(Icons.Default.Add, contentDescription = "Create Team", tint = GoldBright)
                }
            }
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(teams, key = { it.id }) { team ->
                val count = players.count { it.teamId == team.id }
                MetallicCard(
                    onClick = { onOpenTeamPlayers(team.id) }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(CricySurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = team.shortName,
                                color = GoldBright,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = team.name,
                                color = SilverBright,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "$count players · Tap to manage roster",
                                color = SilverMid,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        IconButton(onClick = {
                            editingTeam = team
                            showDialog = true
                        }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Team", tint = SilverMid)
                        }
                        IconButton(onClick = { viewModel.deleteTeam(team) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete Team", tint = WicketCrimson)
                        }
                    }
                }
            }
        }

        Box(modifier = Modifier.padding(16.dp)) {
            GoldHighlightButton(
                text = "Create New Team",
                icon = Icons.Default.Add,
                onClick = {
                    editingTeam = null
                    showDialog = true
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }

    if (showDialog) {
        TeamEditorDialog(
            initial = editingTeam,
            onDismiss = { showDialog = false },
            onSave = { name, shortName ->
                val current = editingTeam
                if (current == null) {
                    viewModel.createTeam(name, shortName, "#D4AF37")
                } else {
                    viewModel.updateTeam(
                        current.copy(
                            name = name.trim(),
                            shortName = shortName.trim().uppercase().take(4).ifEmpty { name.take(3).uppercase() }
                        )
                    )
                }
                showDialog = false
            }
        )
    }
}

@Composable
private fun TeamEditorDialog(
    initial: TeamEntity?,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var shortName by remember { mutableStateOf(initial?.shortName ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CricySurface,
        title = {
            Text(
                text = if (initial == null) "Create Team" else "Edit Team",
                color = SilverBright,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Team Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = CricySurfaceBorder,
                        focusedTextColor = SilverBright,
                        unfocusedTextColor = SilverBright
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = shortName,
                    onValueChange = { shortName = it.uppercase().take(4) },
                    label = { Text("Short Code (e.g. SLV)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = CricySurfaceBorder,
                        focusedTextColor = SilverBright,
                        unfocusedTextColor = SilverBright
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            MetallicSilverButton(
                text = "Save",
                enabled = name.isNotBlank(),
                onClick = { onSave(name, shortName) },
                modifier = Modifier.width(100.dp)
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SilverMid)
            }
        }
    )
}
