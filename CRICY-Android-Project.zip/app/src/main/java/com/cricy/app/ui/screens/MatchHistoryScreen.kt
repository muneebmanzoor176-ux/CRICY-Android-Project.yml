package com.cricy.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricy.app.ui.components.CricyTopBar
import com.cricy.app.ui.components.GoldHighlightButton
import com.cricy.app.ui.components.MetallicCard
import com.cricy.app.ui.components.MetallicSilverButton
import com.cricy.app.ui.theme.CricyBlack
import com.cricy.app.ui.theme.CricySurfaceBorder
import com.cricy.app.ui.theme.CricySurfaceElevated
import com.cricy.app.ui.theme.GoldBright
import com.cricy.app.ui.theme.GoldPrimary
import com.cricy.app.ui.theme.SilverBright
import com.cricy.app.ui.theme.SilverMid
import com.cricy.app.ui.theme.WicketCrimson
import com.cricy.app.ui.theme.WinEmerald
import com.cricy.app.ui.viewmodel.MatchHistoryViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MatchHistoryScreen(
    viewModel: MatchHistoryViewModel,
    onBack: () -> Unit,
    onResumeMatch: (Long) -> Unit,
    onOpenScorecard: (Long) -> Unit
) {
    val allMatches by viewModel.matches.collectAsState()
    var filter by remember { mutableStateOf("ALL") }

    val filtered = remember(allMatches, filter) {
        when (filter) {
            "LIVE" -> allMatches.filter { it.match.status != "COMPLETED" }
            "COMPLETED" -> allMatches.filter { it.match.status == "COMPLETED" }
            else -> allMatches
        }
    }

    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy · HH:mm", Locale.getDefault()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CricyBlack)
            .systemBarsPadding()
    ) {
        CricyTopBar(
            title = "Match History",
            subtitle = "${allMatches.size} SAVED MATCHES",
            onBack = onBack
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("ALL" to "All", "LIVE" to "Unfinished", "COMPLETED" to "Completed").forEach { (key, label) ->
                val selected = filter == key
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) GoldPrimary.copy(alpha = 0.22f) else CricySurfaceElevated)
                        .border(1.dp, if (selected) GoldBright else CricySurfaceBorder, RoundedCornerShape(10.dp))
                        .clickable { filter = key }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        color = if (selected) GoldBright else SilverBright,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No matches recorded in this category yet.",
                    color = SilverMid,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filtered, key = { it.match.id }) { item ->
                    val isDone = item.match.status == "COMPLETED"
                    MetallicCard(goldHighlight = !isDone) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${item.match.format} · ${item.match.oversLimit} ov · ${if (isDone) "COMPLETED" else "IN PROGRESS"}",
                                color = if (isDone) SilverMid else GoldBright,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { viewModel.deleteMatch(item.match.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Match", tint = WicketCrimson)
                            }
                        }
                        Text(
                            text = "${item.teamA?.name ?: "Team A"} vs ${item.teamB?.name ?: "Team B"}",
                            color = SilverBright,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(4.dp))
                        if (item.liveScoreLine.isNotBlank()) {
                            Text(item.liveScoreLine, color = SilverBright, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                        if (item.match.resultSummary.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(item.match.resultSummary, color = WinEmerald, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = dateFormatter.format(Date(item.match.updatedAt)),
                            color = SilverMid,
                            fontSize = 11.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (!isDone) {
                                GoldHighlightButton(
                                    text = "Resume",
                                    icon = Icons.Default.PlayArrow,
                                    onClick = { onResumeMatch(item.match.id) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            MetallicSilverButton(
                                text = "Scorecard",
                                icon = Icons.Default.Assessment,
                                onClick = { onOpenScorecard(item.match.id) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}
