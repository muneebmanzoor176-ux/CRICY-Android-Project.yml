package com.cricy.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricy.app.domain.model.InningsScoreboard
import com.cricy.app.ui.components.CricyTopBar
import com.cricy.app.ui.components.MetallicCard
import com.cricy.app.ui.theme.CricyBlack
import com.cricy.app.ui.theme.CricySurfaceBorder
import com.cricy.app.ui.theme.CricySurfaceElevated
import com.cricy.app.ui.theme.GoldBright
import com.cricy.app.ui.theme.GoldPrimary
import com.cricy.app.ui.theme.SilverBright
import com.cricy.app.ui.theme.SilverMid
import com.cricy.app.ui.theme.WinEmerald
import com.cricy.app.ui.viewmodel.ScorecardViewModel
import java.util.Locale

@Composable
fun ScorecardScreen(
    viewModel: ScorecardViewModel,
    onBack: () -> Unit,
    onOpenPlayerProfile: (Long) -> Unit
) {
    val state by viewModel.liveState.collectAsState()
    val current = state ?: return
    var selectedTab by remember { mutableIntStateOf(if (current.innings2 != null) 1 else 0) }

    val shownInnings = if (selectedTab == 1 && current.innings2 != null) current.innings2!! else current.innings1

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CricyBlack)
            .systemBarsPadding()
    ) {
        CricyTopBar(
            title = "Match Scorecard",
            subtitle = "${current.teamA.shortName} vs ${current.teamB.shortName} · ${current.match.format}",
            onBack = onBack
        )

        if (current.resultSummary.isNotBlank()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(CricySurfaceElevated)
                    .border(1.dp, GoldPrimary.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = current.resultSummary,
                    color = WinEmerald,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            InningsTabChip(
                label = "${current.innings1.battingTeam.shortName} ${current.innings1.totalRuns}/${current.innings1.wickets}",
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                modifier = Modifier.weight(1f)
            )
            current.innings2?.let { i2 ->
                InningsTabChip(
                    label = "${i2.battingTeam.shortName} ${i2.totalRuns}/${i2.wickets}",
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        InningsScorecardContent(
            innings = shownInnings,
            onOpenPlayerProfile = onOpenPlayerProfile,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun InningsTabChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(42.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) GoldPrimary.copy(alpha = 0.22f) else CricySurfaceElevated)
            .border(1.dp, if (selected) GoldBright else CricySurfaceBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) GoldBright else SilverBright,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun InningsScorecardContent(
    innings: InningsScoreboard,
    onOpenPlayerProfile: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            MetallicCard(goldHighlight = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(innings.battingTeam.name, color = GoldBright, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = "${innings.totalRuns}/${innings.wickets} (${innings.oversDisplay} ov)",
                            color = SilverBright,
                            style = MaterialTheme.typography.displayMedium
                        )
                    }
                    Text(
                        text = "CRR ${String.format(Locale.US, "%.2f", innings.currentRunRate)}",
                        color = SilverMid,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Extras: ${innings.extras.total} (wd ${innings.extras.wides}, nb ${innings.extras.noBalls}, b ${innings.extras.byes}, lb ${innings.extras.legByes})",
                    color = SilverMid,
                    fontSize = 12.sp
                )
            }
        }

        // Batting Table
        item {
            MetallicCard(contentPadding = PaddingValues(12.dp)) {
                Text("BATTING", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text("Batter", color = SilverMid, fontSize = 11.sp, modifier = Modifier.weight(1.8f))
                    Text("R", color = SilverMid, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.5f))
                    Text("B", color = SilverMid, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.5f))
                    Text("4s", color = SilverMid, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.45f))
                    Text("6s", color = SilverMid, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.45f))
                    Text("SR", color = SilverMid, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
                }
                Spacer(Modifier.height(6.dp))
                innings.batters.forEach { b ->
                    HorizontalDivider(color = CricySurfaceBorder)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenPlayerProfile(b.player.id) }
                            .padding(vertical = 8.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = b.player.name,
                                color = if (!b.isOut) GoldBright else SilverBright,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1.8f)
                            )
                            Text("${b.runs}", color = SilverBright, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.5f))
                            Text("${b.balls}", color = SilverMid, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.5f))
                            Text("${b.fours}", color = SilverMid, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.45f))
                            Text("${b.sixes}", color = SilverMid, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.45f))
                            Text(String.format(Locale.US, "%.1f", b.strikeRate), color = SilverMid, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.8f))
                        }
                        Text(b.dismissalText, color = SilverMid, fontSize = 11.sp)
                    }
                }
            }
        }

        // Bowling Table
        item {
            MetallicCard(contentPadding = PaddingValues(12.dp)) {
                Text("BOWLING", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text("Bowler", color = SilverMid, fontSize = 11.sp, modifier = Modifier.weight(1.8f))
                    Text("O", color = SilverMid, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.6f))
                    Text("M", color = SilverMid, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.45f))
                    Text("R", color = SilverMid, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.55f))
                    Text("W", color = SilverMid, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.45f))
                    Text("Econ", color = SilverMid, fontSize = 11.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.75f))
                }
                Spacer(Modifier.height(6.dp))
                innings.bowlers.forEach { bw ->
                    HorizontalDivider(color = CricySurfaceBorder)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenPlayerProfile(bw.player.id) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = bw.player.name,
                            color = SilverBright,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1.8f)
                        )
                        Text(bw.oversDisplay, color = SilverMid, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.6f))
                        Text("${bw.maidens}", color = SilverMid, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.45f))
                        Text("${bw.runsConceded}", color = SilverBright, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.55f))
                        Text("${bw.wickets}", color = GoldBright, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.45f))
                        Text(String.format(Locale.US, "%.2f", bw.economy), color = SilverMid, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.75f))
                    }
                }
            }
        }

        // Fall of Wickets
        if (innings.fallOfWickets.isNotEmpty()) {
            item {
                MetallicCard(contentPadding = PaddingValues(12.dp)) {
                    Text("FALL OF WICKETS", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(Modifier.height(8.dp))
                    innings.fallOfWickets.forEach { fow ->
                        Text(
                            text = "${fow.scoreAtFall}/${fow.wicketNumber} (${fow.batterName}, ${fow.overAtFall} ov)",
                            color = SilverBright,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // Partnerships
        if (innings.partnerships.isNotEmpty()) {
            item {
                MetallicCard(contentPadding = PaddingValues(12.dp)) {
                    Text("PARTNERSHIPS", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Spacer(Modifier.height(8.dp))
                    innings.partnerships.forEach { p ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${p.batterOneName} & ${p.batterTwoName}",
                                color = SilverBright,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "${p.runs} (${p.balls})",
                                color = if (p.isActive) GoldBright else SilverMid,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
