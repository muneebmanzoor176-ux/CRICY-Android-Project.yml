package com.cricy.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cricy.app.R
import com.cricy.app.ui.components.GoldHighlightButton
import com.cricy.app.ui.components.MetallicCard
import com.cricy.app.ui.components.MetallicSilverButton
import com.cricy.app.ui.theme.CricyBlack
import com.cricy.app.ui.theme.CricySurfaceElevated
import com.cricy.app.ui.theme.GoldBright
import com.cricy.app.ui.theme.GoldPrimary
import com.cricy.app.ui.theme.SilverBright
import com.cricy.app.ui.theme.SilverMid
import com.cricy.app.ui.theme.SilverPrimary
import com.cricy.app.ui.viewmodel.HomeViewModel

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onNewMatch: () -> Unit,
    onContinueMatch: (Long) -> Unit,
    onMatchHistory: () -> Unit,
    onMyTeams: () -> Unit,
    onMyPlayers: () -> Unit,
    onStatistics: () -> Unit,
    onSettings: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    val activeMatch = state.unfinishedMatches.firstOrNull()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CricyBlack)
            .systemBarsPadding(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Official Brand Masthead
        item {
            MetallicCard(
                goldHighlight = true,
                contentPadding = PaddingValues(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.cricy_logo),
                        contentDescription = "CRICY Official Logo",
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(14.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "CRICY",
                            color = SilverBright,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp
                        )
                        Text(
                            text = "YOUR GAME. YOUR SCORE.",
                            color = GoldBright,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = "MANUAL CRICKET SCORING",
                            color = SilverMid,
                            fontSize = 10.sp,
                            letterSpacing = 1.2.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Scorer: ${state.settings.scorerName}",
                            color = SilverPrimary,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Primary Actions: New Match & Continue Match
        item {
            MetallicSilverButton(
                text = "Start New Match",
                icon = Icons.Default.AddCircle,
                onClick = onNewMatch,
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (activeMatch != null) {
            item {
                MetallicCard(
                    goldHighlight = true,
                    onClick = { onContinueMatch(activeMatch.match.id) }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "UNFINISHED MATCH · ${activeMatch.match.format}",
                                color = GoldBright,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "${activeMatch.teamA?.name ?: "Team A"} vs ${activeMatch.teamB?.name ?: "Team B"}",
                                color = SilverBright,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = activeMatch.liveScoreLine,
                                color = SilverMid,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        GoldHighlightButton(
                            text = "Resume",
                            icon = Icons.Default.PlayArrow,
                            onClick = { onContinueMatch(activeMatch.match.id) },
                            modifier = Modifier.width(118.dp)
                        )
                    }
                }
            }
        }

        // Dashboard Grid (2-column phone-friendly tiles)
        item {
            Text(
                text = "SCORING & CLUB HUB",
                color = SilverMid,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DashboardTile(
                    title = "Continue Match",
                    subtitle = if (state.unfinishedMatches.isEmpty()) "No active match" else "${state.unfinishedMatches.size} active",
                    icon = Icons.Default.SportsCricket,
                    goldAccent = state.unfinishedMatches.isNotEmpty(),
                    onClick = {
                        val first = state.unfinishedMatches.firstOrNull()
                        if (first != null) onContinueMatch(first.match.id) else onMatchHistory()
                    },
                    modifier = Modifier.weight(1f)
                )
                DashboardTile(
                    title = "Match History",
                    subtitle = "${state.totalMatchesCount} matches",
                    icon = Icons.Default.History,
                    onClick = onMatchHistory,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DashboardTile(
                    title = "My Teams",
                    subtitle = "${state.teamsCount} squads",
                    icon = Icons.Default.Groups,
                    onClick = onMyTeams,
                    modifier = Modifier.weight(1f)
                )
                DashboardTile(
                    title = "My Players",
                    subtitle = "${state.playersCount} profiles",
                    icon = Icons.Default.Person,
                    onClick = onMyPlayers,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DashboardTile(
                    title = "Statistics",
                    subtitle = "Career leaders",
                    icon = Icons.Default.BarChart,
                    goldAccent = true,
                    onClick = onStatistics,
                    modifier = Modifier.weight(1f)
                )
                DashboardTile(
                    title = "Settings",
                    subtitle = "Rules & haptics",
                    icon = Icons.Default.Settings,
                    onClick = onSettings,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun DashboardTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    goldAccent: Boolean = false
) {
    MetallicCard(
        modifier = modifier,
        goldHighlight = goldAccent,
        onClick = onClick,
        contentPadding = PaddingValues(16.dp)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(
                            if (goldAccent) GoldPrimary.copy(alpha = 0.22f) else CricySurfaceElevated,
                            CricySurfaceElevated
                        )
                    )
                )
                .border(
                    1.dp,
                    if (goldAccent) GoldPrimary.copy(alpha = 0.6f) else SilverPrimary.copy(alpha = 0.25f),
                    RoundedCornerShape(10.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (goldAccent) GoldBright else SilverBright,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(Modifier.height(12.dp))
        Text(
            text = title,
            color = SilverBright,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = subtitle,
            color = if (goldAccent) GoldPrimary else SilverMid,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
