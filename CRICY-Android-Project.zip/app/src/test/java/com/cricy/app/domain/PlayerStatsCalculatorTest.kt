package com.cricy.app.domain

import com.cricy.app.data.local.entity.DeliveryEntity
import com.cricy.app.data.local.entity.MatchEntity
import com.cricy.app.data.local.entity.PlayerEntity
import com.cricy.app.data.local.entity.TeamEntity
import com.cricy.app.domain.stats.PlayerStatsCalculator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class PlayerStatsCalculatorTest {

    private val teamA = TeamEntity(id = 1L, name = "Silver Strikers", shortName = "SLV")
    private val teamB = TeamEntity(id = 2L, name = "Gold Royals", shortName = "GLD")

    private val batter = PlayerEntity(id = 101L, teamId = 1L, name = "Aarav Sharma")
    private val partner = PlayerEntity(id = 102L, teamId = 1L, name = "Rohan Verma")
    private val bowler = PlayerEntity(id = 201L, teamId = 2L, name = "Samarth Menon")

    @Test
    fun calculates_batting_centuries_fifties_average_sr_and_bowling_best_figures() {
        val match1 = MatchEntity(
            id = 1L, format = "T20", oversLimit = 20, teamAId = 1L, teamBId = 2L,
            teamASquadIdsCsv = "101,102", teamBSquadIdsCsv = "201",
            tossWinnerTeamId = 1L, tossDecision = "BAT", battingFirstTeamId = 1L
        )
        val match2 = MatchEntity(
            id = 2L, format = "T20", oversLimit = 20, teamAId = 1L, teamBId = 2L,
            teamASquadIdsCsv = "101,102", teamBSquadIdsCsv = "201",
            tossWinnerTeamId = 1L, tossDecision = "BAT", battingFirstTeamId = 1L
        )

        val deliveries = mutableListOf<DeliveryEntity>()
        // Match 1: Batter scores 54 off 30 balls (not out) -> 1 fifty
        repeat(9) { idx ->
            deliveries.add(
                DeliveryEntity(
                    id = (idx + 1).toLong(), matchId = 1L, inningsNumber = 1, sequenceNumber = idx + 1,
                    overNumber = idx / 6, ballInOver = (idx % 6) + 1,
                    strikerId = 101L, nonStrikerId = 102L, bowlerId = 201L,
                    runsOffBat = 6, countsAsLegalBall = true
                )
            )
        }
        // Match 2: Batter scores 102 off 51 balls (17 sixes) and gets bowled on 18th ball? Let's do 17 sixes + 1 wicket ball
        repeat(17) { idx ->
            deliveries.add(
                DeliveryEntity(
                    id = (100 + idx).toLong(), matchId = 2L, inningsNumber = 1, sequenceNumber = idx + 1,
                    overNumber = idx / 6, ballInOver = (idx % 6) + 1,
                    strikerId = 101L, nonStrikerId = 102L, bowlerId = 201L,
                    runsOffBat = 6, countsAsLegalBall = true
                )
            )
        }
        deliveries.add(
            DeliveryEntity(
                id = 200L, matchId = 2L, inningsNumber = 1, sequenceNumber = 18,
                overNumber = 2, ballInOver = 6,
                strikerId = 101L, nonStrikerId = 102L, bowlerId = 201L,
                runsOffBat = 0, isWicket = true, wicketType = "BOWLED", dismissedPlayerId = 101L,
                countsAsLegalBall = true
            )
        )

        val stats = PlayerStatsCalculator.calculateAllPlayerStats(
            players = listOf(batter, partner, bowler),
            teams = listOf(teamA, teamB),
            matches = listOf(match1, match2),
            deliveries = deliveries
        )

        val batterStats = stats.first { it.player.id == 101L }
        assertEquals(2, batterStats.matchesPlayed)
        assertEquals(2, batterStats.inningsBatted)
        assertEquals(1, batterStats.notOuts)
        assertEquals(156, batterStats.runsScored)
        assertEquals(27, batterStats.ballsFaced)
        assertEquals(1, batterStats.fifties)
        assertEquals(1, batterStats.centuries)
        assertEquals(102, batterStats.highestScore)
        assertNotNull(batterStats.battingAverage)
        assertEquals(156.0, batterStats.battingAverage!!, 0.01)

        val bowlerStats = stats.first { it.player.id == 201L }
        assertEquals(1, bowlerStats.wicketsTaken)
        assertEquals(156, bowlerStats.runsConceded)
        assertEquals("1/102", bowlerStats.bestFiguresDisplay)
    }
}
