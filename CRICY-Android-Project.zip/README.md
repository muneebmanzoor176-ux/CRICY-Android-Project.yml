# CRICY — Native Android Cricket Scoring Application

**YOUR GAME. YOUR SCORE.**  
*Manual Cricket Scoring · Silver First, Gold Second, Deep Black*

## Tech Stack
- **Language:** Kotlin
- **UI:** Jetpack Compose + Material 3 (Android phone responsive, edge-to-edge)
- **Persistence:** Room (SQLite local database) + DataStore Preferences
- **Architecture:** MVVM + Repository + Pure Deterministic `CricketScoringEngine` & `PlayerStatsCalculator`
- **Media:** Android Photo Picker (`PickVisualMedia`) + internal photo persistence + Coil

## Key Features
- Animated Splash Screen with official CRICY branding (`res/drawable-nodpi/cricy_logo.png`)
- 100% offline-first (no login required) — every delivery auto-saves to Room
- T20 (20 overs), ODI (50 overs), and Custom Overs (1–99)
- One-handed thumb-friendly scoring keypad (`0, 1, 2, 3, 4, 6, WICKET, WIDE, NO BALL, BYE, LEG BYE, UNDO`)
- Automatic strike rotation, over completion, maiden detection, target/RRR, partnerships, fall of wickets, and reliable Undo
- Individual Player Career Statistics (Batting: runs, avg, SR, 100s, 50s, 4s/6s; Bowling: wickets, avg, economy, best figures, maidens) updated automatically after every delivery

## Build APK in Android Studio
1. Open the `android/` directory in **Android Studio (Ladybug or newer)**.
2. Wait for Gradle Sync (`Gradle 8.10.2` / `AGP 8.7.3` / `JDK 17`).
3. Run **Build > Build Bundle(s) / APK(s) > Build APK(s)** or run:
   ```bash
   ./gradlew assembleDebug
   ./gradlew testDebugUnitTest
   ```
